/*
 * keypad.js — логика нажатия кнопок (без DOM, поэтому легко тестируется).
 *
 * Состояние: { expr, done, error, value, entry }
 *   expr  — текст выражения («2+3×4», «9^100», «3√27»)
 *   done  — нажато «=»: показываем результат
 *   error — текст ошибки (если вычисление не удалось)
 *   value — результат (BigInt или Number)
 *   entry — новая запись для истории (читается один раз после нажатия «=»)
 *
 * Ключи кнопок: '0'..'9', '.', '+', '−', '×', '÷', '(', ')', '%',
 *               'pow' (xʸ), 'sqrt' (√), 'root' (ʸ√), 'sign' (±), 'back' (⌫), 'ac', 'eq'
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./calc.js'));
  else root.Keypad = factory(root.Calc);
})(typeof self !== 'undefined' ? self : this, function (Calc) {
  'use strict';

  const OPS = '+−×÷';
  const MAX_LEN = 400;   // максимальная длина выражения
  const MAX_RUN = 60;    // максимум цифр в одном числе

  const inSet = (set, c) => c !== '' && set.includes(c);
  const isDigit = (c) => c !== '' && c >= '0' && c <= '9';
  const isOp = (c) => inSet(OPS, c);
  const lastOf = (e) => e.charAt(e.length - 1);
  const endsOperand = (e) => {
    const c = lastOf(e);
    return isDigit(c) || c === ')' || c === '%' || c === '.';
  };
  const isNegative = (s) => /^[-−]/.test(s);

  function createState() {
    return { expr: '', done: false, error: null, value: null, entry: null };
  }

  function clear(s) {
    s.expr = ''; s.done = false; s.error = null; s.value = null;
    return s;
  }

  // после «=» начинаем новое выражение
  function fresh(s) {
    if (s.done) clear(s);
  }

  // после «=» продолжаем считать с результата
  function resume(s, wrapNegative) {
    if (!(s.done && !s.error)) return;
    let e = Calc.serialize(s.value);
    if (wrapNegative && isNegative(e)) e = '(' + e + ')';
    s.expr = e; s.done = false; s.error = null;
  }

  function digit(s, d) {
    fresh(s);
    let e = s.expr;
    if (lastOf(e) === ')' || lastOf(e) === '%') e += '×';
    else if (/(^|[^\d.E])0$/.test(e)) e = e.slice(0, -1);       // без ведущих нулей: 05 → 5
    if (/[\d.]*$/.exec(e)[0].length >= MAX_RUN) return;
    s.expr = e + d;
  }

  function dot(s) {
    fresh(s);
    const e = s.expr;
    const c = lastOf(e);
    if (c === ')' || c === '%') s.expr = e + '×0.';
    else if (!isDigit(c) && c !== '.') s.expr = e + '0.';
    else if (!/[\d.]*$/.exec(e)[0].includes('.')) s.expr = e + '.';
  }

  function operator(s, o) {
    resume(s, false);
    let e = s.expr;
    const c = lastOf(e);
    if (e === '') { if (o === '−') s.expr = '−'; return; }
    if (inSet('(^√', c)) { if (o === '−') s.expr = e + '−'; return; }   // унарный минус: 2^−3, (−5
    if (isOp(c)) {
      if (o === '−' && (c === '×' || c === '÷')) { s.expr = e + '−'; return; }   // 2×−3
      e = e.replace(/[+−×÷]+$/, '');                                              // замена оператора
      if (e === '') { s.expr = o === '−' ? '−' : ''; return; }
      if (inSet('(^√', lastOf(e))) { s.expr = o === '−' ? e + '−' : e; return; }
    }
    s.expr = e + o;
  }

  function open(s) {
    fresh(s);
    s.expr += endsOperand(s.expr) ? '×(' : '(';
  }

  function close(s) {
    if (s.done) return;
    const opens = (s.expr.match(/\(/g) || []).length;
    const closes = (s.expr.match(/\)/g) || []).length;
    if (opens > closes && endsOperand(s.expr)) s.expr += ')';
  }

  function percent(s) {
    resume(s, true);
    if (endsOperand(s.expr)) s.expr += '%';
  }

  function power(s) {
    resume(s, true);
    if (endsOperand(s.expr)) s.expr += '^';
  }

  function sqrt(s) {
    if (s.done && !s.error) {
      const v = Calc.serialize(s.value);
      s.expr = '√' + (Calc.isPlainNumber(v) && !isNegative(v) ? v : '(' + v + ')');
      s.done = false;
      return;
    }
    const e = s.expr;
    s.expr = endsOperand(e) ? e + '×√' : e + '√';
  }

  function nthRoot(s) {
    resume(s, true);
    const e = s.expr;
    if (endsOperand(e) && lastOf(e) !== '%') s.expr = e + '√';
  }

  // в позиции idx стоит унарный минус (а не вычитание)?
  const isUnaryAt = (e, idx) => idx === 0 || inSet('(^√×÷+−', e.charAt(idx - 1));

  function sign(s) {
    if (s.done && !s.error) {
      resume(s, false);
      s.expr = isNegative(s.expr) ? s.expr.slice(1) : '−' + s.expr;
      return;
    }
    const e = s.expr;
    const c = lastOf(e);
    if (e === '' || inSet('(^√+×÷', c)) { s.expr = e + '−'; return; }
    if (c === '−') {
      s.expr = isUnaryAt(e, e.length - 1) ? e.slice(0, -1) : e + '−';
      return;
    }
    if (isDigit(c) || c === '.') {
      const run = /[\d.]+$/.exec(e)[0];
      const i = e.length - run.length;
      if (e.charAt(i - 1) === '−' && isUnaryAt(e, i - 1)) s.expr = e.slice(0, i - 1) + e.slice(i);
      else s.expr = e.slice(0, i) + '−' + e.slice(i);
    }
  }

  function back(s) {
    if (s.done) {              // вернуться к редактированию выражения
      s.done = false; s.error = null; s.value = null;
      return;
    }
    s.expr = s.expr.slice(0, -1);
  }

  function equals(s) {
    if (s.done || s.expr === '') return;
    const src = Calc.prepare(s.expr);
    if (src === '') return;
    s.expr = src;
    try {
      const v = Calc.evaluate(src);
      s.value = v; s.error = null; s.done = true;
      if (!Calc.isPlainNumber(src)) s.entry = { expr: src, res: Calc.serialize(v) };
    } catch (err) {
      s.value = null; s.done = true;
      s.error = err instanceof Calc.CalcError ? err.message : Calc.MESSAGES.syntax;
    }
  }

  function press(s, key) {
    s.entry = null;
    if (key === 'ac') { clear(s); return s; }
    if (key === 'back') { back(s); return s; }
    if (key === 'eq') { equals(s); return s; }

    if (s.done && s.error) {
      // после ошибки продолжить можно только «с чистого листа»
      if (isDigit(key) || key === '.' || key === '(' || key === 'sqrt' || key === '−') clear(s);
      else return s;
    }
    if (!s.done && s.expr.length >= MAX_LEN) return s;

    if (isDigit(key)) { digit(s, key); return s; }
    switch (key) {
      case '.': dot(s); break;
      case '+': case '−': case '×': case '÷': operator(s, key); break;
      case '(': open(s); break;
      case ')': close(s); break;
      case '%': percent(s); break;
      case 'pow': power(s); break;
      case 'sqrt': sqrt(s); break;
      case 'root': nthRoot(s); break;
      case 'sign': sign(s); break;
      default: break;
    }
    return s;
  }

  // подставить готовое число (например, из истории)
  function insert(s, text) {
    if (s.done) clear(s);
    if (endsOperand(s.expr)) s.expr += '×';
    s.expr += text;
    return s;
  }

  // «живой» результат под выражением (или null)
  function preview(s) {
    if (s.done || s.expr === '') return null;
    const src = Calc.prepare(s.expr);
    if (src === '' || Calc.isPlainNumber(src)) return null;
    try { return Calc.evaluate(src); } catch (e) { return null; }
  }

  const KEYS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '+', '−', '×', '÷', '(', ')', '%',
    'pow', 'sqrt', 'root', 'sign', 'back', 'ac', 'eq'];

  return { createState, press, insert, preview, KEYS };
});
