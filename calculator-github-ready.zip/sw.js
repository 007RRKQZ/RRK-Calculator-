/* Service worker: после первой загрузки приложение работает без интернета.
 * Стратегия: отдаём из кэша сразу, а в фоне обновляем кэш.
 * При изменении файлов увеличьте номер в CACHE — старый кэш удалится сам. */
const CACHE = 'calc-v1';

const ASSETS = [
  './',
  'index.html',
  'style.css',
  'calc.js',
  'keypad.js',
  'app.js',
  'manifest.json',
  'icons/icon.svg',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/apple-touch-icon.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then((hit) => {
      const network = fetch(req).then((res) => {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then((cache) => cache.put(req, copy));
        }
        return res;
      });
      if (hit) {
        network.catch(() => {});
        return hit;
      }
      return network.catch(() =>
        req.mode === 'navigate' ? caches.match('index.html') : Response.error()
      );
    })
  );
});
