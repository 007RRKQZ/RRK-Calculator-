/* app.js — интерфейс: отрисовка, события, история, регистрация service worker */
(function () {
  'use strict';

  const Calc = window.Calc;
  const Keypad = window.Keypad;
  const $ = (id) => document.getElementById(id);

  const el = {
    display: $('display'),
    expr: $('expr'),
    result: $('result'),
    hint: $('hint'),
    keys: $('keys'),
    sheet: $('sheet'),
    list: $('hist-list'),
  };

  const state = Keypad.createState();
  let showExact = false;

  /* ───────────── история (только на устройстве) ───────────── */

  const HISTORY_KEY = 'calc.history.v1';
  const HISTORY_MAX = 30;

  function loadHistory() {
    try {
      const data = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
      return Array.isArray(data)
        ? data.filter((h) => h && typeof h.e === 'string' && typeof h.r === 'string').slice(0, HISTORY_MAX)
        : [];
    } catch (e) {
      return [];
    }
  }

  function saveHistory() {
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify(history)); } catch (e) { /* приватный режим */ }
  }

  let history = loadHistory();

  function pushHistory(entry) {
    if (history[0] && history[0].e === entry.expr && history[0].r === entry.res) return;
    history.unshift({ e: entry.expr, r: entry.res });
    history = history.slice(0, HISTORY_MAX);
    saveHistory();
  }

  /* ───────────── отрисовка выражения ───────────── */

  const escapeHtml = (s) => s.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  const NUM_RE = /(?:\d+\.?\d*|\.\d+)(?:E[+-]?\d+)?/y;

  function fmtNum(text, grouped) {
    const m = /^([\d.]*)(?:E([+-]?\d+))?$/.exec(text);
    if (!m) return escapeHtml(text);
    const parts = m[1].split('.');
    let out = grouped ? Calc.group(parts[0]) : parts[0];
    if (m[1].includes('.')) out += ',' + (parts[1] || '');
    if (m[2] !== undefined) out += '×10<sup>' + m[2].replace('+', '').replace('-', '−') + '</sup>';
    return out;
  }

  // «9^100» → 9 с верхним индексом 100, «3√27» → ³√27
  function renderExpr(s, inSup) {
    let out = '';
    let i = 0;
    while (i < s.length) {
      const c = s[i];

      NUM_RE.lastIndex = i;
      const m = NUM_RE.exec(s);
      if (m) {
        i += m[0].length;
        out += s[i] === '√' && !inSup
          ? '<sup class="deg">' + fmtNum(m[0], false) + '</sup>'
          : fmtNum(m[0], !inSup);
        continue;
      }

      if (c === '^' && !inSup) {
        let j = i + 1;
        while (j < s.length && '−-+'.includes(s[j])) j++;
        let end = j;
        if (s[j] === '(') {
          let depth = 0;
          let k = j;
          for (; k < s.length; k++) {
            if (s[k] === '(') depth++;
            else if (s[k] === ')' && --depth === 0) { k++; break; }
          }
          end = k;
        } else {
          NUM_RE.lastIndex = j;
          const mm = NUM_RE.exec(s);
          end = mm ? j + mm[0].length : j;
        }
        const inner = s.slice(i + 1, end);
        out += inner === ''
          ? '<sup class="exp ph"></sup>'
          : '<sup class="exp">' + renderExpr(inner, true) + '</sup>';
        i = end;
        continue;
      }

      if ('+−-×÷'.includes(c)) {
        const shown = c === '-' ? '−' : c;
        const prev = s[i - 1];
        const binary = prev !== undefined && /[\d.)%]/.test(prev);
        out += binary && !inSup ? '<span class="op">' + shown + '</span>' : shown;
      } else {
        out += escapeHtml(c);
      }
      i++;
    }
    return out;
  }

  /* ───────────── отрисовка экрана ───────────── */

  function fit(node, max, min) {
    node.classList.remove('wrap');
    let size = max;
    node.style.fontSize = size + 'px';
    while (node.scrollWidth > node.clientWidth + 1 && size > min) {
      size -= 2;
      node.style.fontSize = size + 'px';
    }
    if (node.scrollWidth > node.clientWidth + 1) node.classList.add('wrap');
  }

  function render() {
    const done = state.done;
    let exact = null;

    el.display.classList.toggle('done', done);
    el.result.classList.remove('error', 'exact', 'has-exact', 'wrap');

    if (!done) {
      el.expr.innerHTML = state.expr === '' ? '0' : renderExpr(state.expr);
      const pv = Keypad.preview(state);
      el.result.innerHTML = pv === null ? '&nbsp;' : Calc.format(pv).html;
      fit(el.expr, 60, 30);
      fit(el.result, 26, 16);
    } else {
      el.expr.innerHTML = renderExpr(state.expr);
      fit(el.expr, 28, 16);
      if (state.error) {
        el.result.textContent = state.error;
        el.result.classList.add('error');
        fit(el.result, 36, 20);
      } else {
        const f = Calc.format(state.value);
        exact = f.exact;
        if (showExact && exact) {
          el.result.textContent = exact;
          el.result.classList.add('exact', 'has-exact');
          el.result.style.fontSize = '24px';
        } else {
          el.result.innerHTML = f.html;
          fit(el.result, 76, 30);
          if (exact) el.result.classList.add('has-exact');
        }
      }
    }

    el.hint.hidden = !(exact && !showExact);
    el.result.dataset.exact = exact ? '1' : '';
    el.display.scrollTop = el.display.scrollHeight;
  }

  function press(key) {
    showExact = false;
    Keypad.press(state, key);
    if (state.entry) pushHistory(state.entry);
    render();
  }

  /* ───────────── события ───────────── */

  el.keys.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-key]');
    if (b) press(b.dataset.key);
  });

  $('btn-back').addEventListener('click', () => press('back'));

  el.result.addEventListener('click', () => {
    if (el.result.dataset.exact !== '1') return;
    showExact = !showExact;
    render();
  });

  // лёгкая анимация нажатия (работает и на iOS без :active)
  document.addEventListener('pointerdown', (e) => {
    const b = e.target.closest('button');
    if (b) b.classList.add('pressed');
  }, { passive: true });

  const release = () => {
    setTimeout(() => {
      document.querySelectorAll('.pressed').forEach((b) => b.classList.remove('pressed'));
    }, 70);
  };
  document.addEventListener('pointerup', release, { passive: true });
  document.addEventListener('pointercancel', release, { passive: true });

  // смахивание по дисплею влево/вправо — удалить последний символ
  let touchX = 0;
  let touchY = 0;
  el.display.addEventListener('touchstart', (e) => {
    touchX = e.changedTouches[0].clientX;
    touchY = e.changedTouches[0].clientY;
  }, { passive: true });
  el.display.addEventListener('touchend', (e) => {
    const dx = e.changedTouches[0].clientX - touchX;
    const dy = e.changedTouches[0].clientY - touchY;
    if (Math.abs(dx) > 50 && Math.abs(dy) < 30) press('back');
  }, { passive: true });

  // без масштабирования жестами
  document.addEventListener('gesturestart', (e) => e.preventDefault());

  // клавиатура (удобно для проверки на компьютере)
  const KEY_MAP = {
    '*': '×', x: '×', X: '×', '/': '÷', '-': '−', ',': '.', '^': 'pow',
    Enter: 'eq', '=': 'eq', Backspace: 'back', Escape: 'ac', Delete: 'ac',
  };
  document.addEventListener('keydown', (e) => {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (el.sheet.classList.contains('open')) {
      if (e.key === 'Escape') closeSheet();
      return;
    }
    const key = KEY_MAP[e.key] || e.key;
    if (Keypad.KEYS.includes(key)) {
      e.preventDefault();
      press(key);
    }
  });

  /* ───────────── история: окно ───────────── */

  function renderHistory() {
    if (!history.length) {
      el.list.innerHTML = '<li class="hist-empty">Здесь появятся ваши вычисления</li>';
      return;
    }
    el.list.innerHTML = history.map((h, i) => {
      let res = '';
      try { res = Calc.format(Calc.evaluate(h.r)).html; } catch (e) { res = escapeHtml(h.r); }
      return '<li><button class="hist-item" type="button" data-i="' + i + '">' +
        '<span class="hist-expr">' + renderExpr(h.e) + '</span>' +
        '<span class="hist-res">= ' + res + '</span></button></li>';
    }).join('');
  }

  function openSheet() {
    renderHistory();
    el.sheet.classList.add('open');
    el.sheet.setAttribute('aria-hidden', 'false');
  }

  function closeSheet() {
    el.sheet.classList.remove('open');
    el.sheet.setAttribute('aria-hidden', 'true');
  }

  $('btn-history').addEventListener('click', openSheet);
  $('hist-close').addEventListener('click', closeSheet);
  $('scrim').addEventListener('click', closeSheet);
  $('hist-clear').addEventListener('click', () => {
    history = [];
    saveHistory();
    renderHistory();
  });
  el.list.addEventListener('click', (e) => {
    const b = e.target.closest('.hist-item');
    if (!b) return;
    const item = history[Number(b.dataset.i)];
    if (!item) return;
    showExact = false;
    Keypad.insert(state, item.r);
    closeSheet();
    render();
  });

  /* ───────────── запуск ───────────── */

  window.addEventListener('resize', render);
  window.addEventListener('orientationchange', render);
  render();

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').catch(() => { /* офлайн-режим недоступен, но приложение работает */ });
    });
  }
})();
