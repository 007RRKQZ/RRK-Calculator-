/* Запуск: node tests/run.js */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const Calc = require('../calc.js');
const Keypad = require('../keypad.js');

const ROOT = path.join(__dirname, '..');
let passed = 0;
let failed = 0;

function t(name, fn) {
  try { fn(); passed++; } catch (e) { failed++; console.log('✗', name, '\n    ', e.message); }
}

const ev = (s) => Calc.evaluate(s);
const txt = (v) => Calc.format(v).text;
const NB = '\u202f';

function errCode(src) {
  try { ev(src); } catch (e) { return e.code; }
  return null;
}

function run(keys) {
  const s = Keypad.createState();
  keys.split(' ').filter(Boolean).forEach((k) => Keypad.press(s, k));
  return s;
}
const out = (keys) => { const s = run(keys); return s.error || txt(s.value); };

/* ───────── движок ───────── */

t('приоритет операций', () => { assert.strictEqual(ev('2+3×4'), 14n); assert.strictEqual(ev('(2+3)×4'), 20n); });
t('деление', () => { assert.strictEqual(ev('10÷4'), 2.5); assert.strictEqual(ev('12÷4'), 3n); });
t('унарный минус и степень: −2^2 = −4', () => assert.strictEqual(ev('−2^2'), -4n));
t('степень правоассоциативна: 2^3^2 = 512', () => assert.strictEqual(ev('2^3^2'), 512n));
t('нулевая степень', () => { assert.strictEqual(ev('7^0'), 1n); assert.strictEqual(ev('9^0'), 1n); });
t('0⁰ — ошибка', () => assert.strictEqual(errCode('0^0'), 'zero0'));
t('0^5 = 0, 0^−1 — деление на ноль', () => { assert.strictEqual(ev('0^5'), 0n); assert.strictEqual(errCode('0^−1'), 'div0'); });
t('отрицательные степени', () => { assert.strictEqual(ev('2^−3'), 0.125); assert.strictEqual(ev('10^−2'), 0.01); });
t('7^15 точно', () => assert.strictEqual(ev('7^15'), 4747561509943n));
t('9^100 точно (все 96 цифр)', () => { assert.strictEqual(ev('9^100'), 9n ** 100n); assert.ok(txt(ev('9^100')).endsWith('10^95')); });
t('научная запись 9^100', () => assert.strictEqual(txt(ev('9^100')), '2,656139889×10^95'));
t('10^400 точно', () => { assert.strictEqual(ev('10^400'), 10n ** 400n); assert.strictEqual(txt(ev('10^400')), '1×10^400'); });
t('переполнение', () => { assert.strictEqual(errCode('9^9999999'), 'overflow'); assert.strictEqual(errCode('10^400×10^400×10^400'), null); assert.strictEqual(errCode('9^5000'), 'overflow'); });
t('слишком малое число', () => assert.strictEqual(errCode('9^−400'), 'underflow'));
t('деление на ноль', () => { assert.strictEqual(errCode('5÷0'), 'div0'); assert.strictEqual(errCode('5÷(3−3)'), 'div0'); assert.strictEqual(errCode('5÷0,0'.replace(',', '.')), 'div0'); });
t('квадратный корень', () => { assert.strictEqual(ev('√16'), 4n); assert.strictEqual(txt(ev('√2')), '1,41421356237'); assert.strictEqual(ev('√0'), 0n); });
t('корень из отрицательного', () => assert.strictEqual(errCode('√−4'), 'noreal'));
t('корень n-й степени', () => { assert.strictEqual(ev('3√27'), 3n); assert.strictEqual(ev('3√−8'), -2n); assert.strictEqual(ev('4√81'), 3n); assert.strictEqual(errCode('4√−16'), 'noreal'); assert.strictEqual(errCode('0√5'), 'badroot'); });
t('корень из огромной степени: √(9^1000) = 3^1000', () => assert.strictEqual(ev('√(9^1000)'), 3n ** 1000n));
t('корень: несовершенный куб', () => assert.strictEqual(txt(ev('3√10')), '2,15443469003'));
t('отрицательное основание с дробной степенью', () => assert.strictEqual(errCode('(−8)^(1÷3)'), 'noreal'));
t('отрицательное основание, целая степень', () => { assert.strictEqual(ev('(−2)^3'), -8n); assert.strictEqual(ev('(−2)^4'), 16n); });
t('проценты', () => {
  assert.strictEqual(ev('100+10%'), 110n);
  assert.strictEqual(ev('200−10%'), 180n);
  assert.strictEqual(ev('50%'), 0.5);
  assert.strictEqual(txt(ev('50×10%')), '5');
});
t('десятичные без шума', () => { assert.strictEqual(txt(ev('0.1+0.2')), '0,3'); assert.strictEqual(txt(ev('1÷3')), '0,333333333333'); });
t('неявное умножение', () => { assert.strictEqual(ev('2(3+4)'), 14n); assert.strictEqual(ev('(1+1)(2+2)'), 8n); });
t('неправильные выражения', () => {
  for (const s of ['', '+', '5+', '(', ')', '()', '2(', '5%%%a', '2^', '√', '1..2'.replace('..', '.2.')]) {
    if (s === '') continue;
    assert.notStrictEqual(errCode(s), null, 'ожидалась ошибка: ' + JSON.stringify(s));
  }
});
t('нет eval и опасного ввода', () => {
  assert.strictEqual(errCode('alert(1)'), 'syntax');
  assert.strictEqual(errCode('2**3'), 'syntax');
  assert.strictEqual(errCode('constructor'), 'syntax');
});
t('огромные целые остаются точными', () => assert.strictEqual(ev('12345678901234567890+1'), 12345678901234567891n));
t('научная запись малых чисел', () => { assert.strictEqual(txt(ev('10^−7')), '1×10^−7'); assert.strictEqual(txt(ev('10^−5')), '0,00001'); });
t('форматирование разрядов', () => assert.strictEqual(txt(ev('1234567')), '1' + NB + '234' + NB + '567'));
t('prepare закрывает скобки и убирает хвост', () => { assert.strictEqual(Calc.prepare('2×(3+'), '2×(3'.replace('(3', '(3') + ')'); assert.strictEqual(Calc.prepare('5+'), '5'); });
t('serialize → evaluate возвращает то же', () => {
  for (const s of ['2^0.5', '10^−7', '10^30÷7', '1÷3']) {
    const v = ev(s);
    const back = ev(Calc.serialize(v));
    assert.ok(Math.abs(Number(back) - Number(v)) <= Math.abs(Number(v)) * 1e-13, s);
  }
});

/* ───────── кнопки ───────── */

t('кнопки: приоритет', () => assert.strictEqual(out('2 + 3 × 4 eq'), '14'));
t('кнопки: скобки', () => assert.strictEqual(out('( 2 + 3 ) × 4 eq'), '20'));
t('кнопки: деление', () => assert.strictEqual(out('1 0 ÷ 4 eq'), '2,5'));
t('кнопки: деление на ноль', () => assert.strictEqual(out('5 ÷ 0 eq'), 'Деление на ноль'));
t('кнопки: 0⁰', () => assert.strictEqual(out('0 pow 0 eq'), '0⁰ не определён'));
t('кнопки: 2²', () => assert.strictEqual(out('2 pow 2 eq'), '4'));
t('кнопки: 3⁵', () => assert.strictEqual(out('3 pow 5 eq'), '243'));
t('кнопки: 7¹⁵', () => assert.strictEqual(run('7 pow 1 5 eq').value, 4747561509943n));
t('кнопки: 9¹⁰⁰', () => assert.strictEqual(run('9 pow 1 0 0 eq').value, 9n ** 100n));
t('кнопки: отрицательная степень', () => assert.strictEqual(out('2 pow sign 3 eq'), '0,125'));
t('кнопки: 5⁰', () => assert.strictEqual(out('5 pow 0 eq'), '1'));
t('кнопки: переполнение', () => assert.strictEqual(out('9 pow 9 9 9 9 9 9 9 eq'), 'Переполнение'));
t('кнопки: √', () => assert.strictEqual(out('sqrt 1 6 eq'), '4'));
t('кнопки: √(16+9)', () => assert.strictEqual(out('sqrt ( 1 6 + 9 ) eq'), '5'));
t('кнопки: ³√27', () => assert.strictEqual(out('3 root 2 7 eq'), '3'));
t('кнопки: ³√−8', () => assert.strictEqual(out('3 root sign 8 eq'), '−2'));
t('кнопки: √ после числа → умножение', () => assert.strictEqual(out('2 sqrt 9 eq'), '6'));
t('кнопки: √2×√2', () => assert.strictEqual(out('sqrt 2 × sqrt 2 eq'), '2'));
t('кнопки: проценты', () => assert.strictEqual(out('1 0 0 + 1 0 % eq'), '110'));
t('кнопки: 0,1 + 0,2', () => assert.strictEqual(out('0 . 1 + 0 . 2 eq'), '0,3'));
t('кнопки: ± на числе', () => { assert.strictEqual(run('5 sign').expr, '−5'); assert.strictEqual(run('5 sign sign').expr, '5'); assert.strictEqual(out('5 sign eq'), '−5'); });
t('кнопки: ± внутри выражения', () => { assert.strictEqual(out('2 + 3 sign eq'), '−1'); assert.strictEqual(run('5 − 3 sign').expr, '5−−3'); assert.strictEqual(run('5 − 3 sign sign').expr, '5−3'); });
t('кнопки: ± после результата', () => { const s = run('2 + 3 eq sign'); assert.strictEqual(s.expr, '−5'); assert.strictEqual(s.done, false); });
t('кнопки: ⌫', () => { assert.strictEqual(run('1 2 back').expr, '1'); assert.strictEqual(out('1 2 back back 3 eq'), '3'); });
t('кнопки: ⌫ после = возвращает выражение', () => { const s = run('1 + 2 eq back'); assert.strictEqual(s.done, false); assert.strictEqual(s.expr, '1+2'); });
t('кнопки: AC', () => { const s = run('1 + 2 eq ac'); assert.strictEqual(s.expr, ''); assert.strictEqual(s.done, false); });
t('кнопки: продолжение с результата', () => assert.strictEqual(out('1 + 2 eq + 3 eq'), '6'));
t('кнопки: цифра после = начинает заново', () => assert.strictEqual(out('1 + 2 eq 5 eq'), '5'));
t('кнопки: степень результата', () => assert.strictEqual(out('3 sign eq pow 2 eq'), '9'));
t('кнопки: висящий оператор', () => assert.strictEqual(out('2 + eq'), '2'));
t('кнопки: автозакрытие скобок', () => assert.strictEqual(out('( 2 + 3 eq'), '5'));
t('кнопки: ) без ( игнорируется', () => assert.strictEqual(run(') 5').expr, '5'));
t('кнопки: ( после числа → умножение', () => assert.strictEqual(out('2 ( 3 eq'), '6'));
t('кнопки: замена оператора', () => { assert.strictEqual(run('5 + ×').expr, '5×'); assert.strictEqual(out('5 + × 3 eq'), '15'); });
t('кнопки: 2×−3', () => assert.strictEqual(out('6 × − 2 eq'), '−12'));
t('кнопки: ведущие нули', () => { assert.strictEqual(run('0 0 5').expr, '5'); assert.strictEqual(run('0 . 0 5').expr, '0.05'); });
t('кнопки: десятичная точка', () => { assert.strictEqual(run('.').expr, '0.'); assert.strictEqual(run('1 . 2 .').expr, '1.2'); assert.strictEqual(run('5 + .').expr, '5+0.'); });
t('кнопки: %', () => assert.strictEqual(out('5 0 % eq'), '0,5'));
t('кнопки: xʸ без числа игнорируется', () => assert.strictEqual(run('pow').expr, ''));
t('кнопки: ʸ√ без числа игнорируется', () => assert.strictEqual(run('root').expr, ''));
t('кнопки: пустой eq', () => assert.strictEqual(run('eq').done, false));
t('кнопки: после ошибки цифра начинает заново', () => assert.strictEqual(run('5 ÷ 0 eq 7').expr, '7'));
t('кнопки: после ошибки ⌫ возвращает выражение', () => assert.strictEqual(run('5 ÷ 0 eq back').expr, '5÷0'));
t('кнопки: запись в историю', () => { const s = run('2 + 3 eq'); assert.deepStrictEqual(s.entry, { expr: '2+3', res: '5' }); assert.strictEqual(run('5 eq').entry, null); });
t('кнопки: история → insert', () => { const s = run('2 +'); Keypad.insert(s, '25'); assert.strictEqual(s.expr, '2+25'); });
t('кнопки: превью', () => { assert.strictEqual(Keypad.preview(run('2 + 3')), 5n); assert.strictEqual(Keypad.preview(run('2 +')), null); assert.strictEqual(Keypad.preview(run('5')), null); });
t('кнопки: 10⁴⁰⁰', () => assert.strictEqual(out('1 0 pow 4 0 0 eq'), '1×10^400'));
t('кнопки: (−8)³', () => assert.strictEqual(out('( − 8 ) pow 3 eq'), '−512'));
t('кнопки: (−8)^(1/3) → нет вещественного результата', () => assert.strictEqual(out('( − 8 ) pow ( 1 ÷ 3 ) eq'), 'Нет вещественного результата'));
t('кнопки: очень длинный ввод не ломается', () => {
  const s = Keypad.createState();
  for (let i = 0; i < 1000; i++) Keypad.press(s, '9');
  assert.ok(s.expr.length <= 400);
  Keypad.press(s, 'eq');
  assert.ok(s.done);
});
t('кнопки: случайные нажатия не падают', () => {
  const s = Keypad.createState();
  let seed = 12345;
  const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  for (let i = 0; i < 20000; i++) {
    Keypad.press(s, Keypad.KEYS[Math.floor(rnd() * Keypad.KEYS.length)]);
    Keypad.preview(s);
  }
});

/* ───────── PWA-файлы ───────── */

t('index.html: мета-теги PWA/iOS', () => {
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  for (const needle of [
    'rel="manifest"', 'name="theme-color"', 'apple-mobile-web-app-capable" content="yes"',
    'apple-mobile-web-app-status-bar-style', 'apple-mobile-web-app-title', 'rel="apple-touch-icon"', 'viewport-fit=cover',
  ]) assert.ok(html.includes(needle), 'нет ' + needle);
});
t('index.html: все data-key известны, ничего не пропущено', () => {
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  const keys = [...html.matchAll(/data-key="([^"]+)"/g)].map((m) => m[1]);
  assert.strictEqual(keys.length, 24);
  for (const k of keys) assert.ok(Keypad.KEYS.includes(k), 'неизвестная кнопка ' + k);
  assert.strictEqual(new Set(keys).size, keys.length);
});
t('manifest.json: standalone и иконки существуют', () => {
  const m = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
  assert.strictEqual(m.display, 'standalone');
  assert.ok(m.name && m.short_name && m.start_url && m.theme_color && m.background_color);
  for (const i of m.icons) assert.ok(fs.existsSync(path.join(ROOT, i.src)), 'нет файла ' + i.src);
});
t('иконки PNG нужных размеров', () => {
  const size = (f) => { const b = fs.readFileSync(path.join(ROOT, 'icons', f)); return [b.readUInt32BE(16), b.readUInt32BE(20)]; };
  assert.deepStrictEqual(size('apple-touch-icon.png'), [180, 180]);
  assert.deepStrictEqual(size('icon-192.png'), [192, 192]);
  assert.deepStrictEqual(size('icon-512.png'), [512, 512]);
});
t('sw.js: все файлы кэша существуют', () => {
  const sw = fs.readFileSync(path.join(ROOT, 'sw.js'), 'utf8');
  const list = /const ASSETS = \[([\s\S]*?)\];/.exec(sw)[1];
  const files = [...list.matchAll(/'([^']+)'/g)].map((m) => m[1]).filter((f) => f !== './');
  assert.ok(files.length >= 8);
  for (const f of files) assert.ok(fs.existsSync(path.join(ROOT, f)), 'нет файла ' + f);
});
t('в коде нет eval / new Function', () => {
  for (const f of ['calc.js', 'keypad.js', 'app.js']) {
    const src = fs.readFileSync(path.join(ROOT, f), 'utf8');
    assert.ok(!/\beval\s*\(/.test(src) && !/new Function/.test(src), f);
  }
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
