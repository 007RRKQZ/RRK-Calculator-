/*
 * calc.js — математическое ядро калькулятора.
 *
 * Без использования eval: токенайзер → рекурсивный парсер → вычисление дерева.
 * Целые числа считаются ТОЧНО (BigInt), всё остальное — обычные числа JS (double).
 * Поэтому 9^100 выдаёт все 96 цифр без потерь, а 0,1 + 0,2 показывается как 0,3.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Calc = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const MAX_BITS = 4096;          // предел точных целых (~1233 десятичные цифры)
  const MAX_LITERAL_DIGITS = 1200;
  const NNBSP = '\u202f';         // узкий неразрывный пробел для разрядов

  const MESSAGES = {
    syntax: 'Ошибка',
    div0: 'Деление на ноль',
    zero0: '0⁰ не определён',
    overflow: 'Переполнение',
    underflow: 'Слишком малое число',
    noreal: 'Нет вещественного результата',
    badroot: 'Корень нулевой степени',
  };

  class CalcError extends Error {
    constructor(code) {
      super(MESSAGES[code] || MESSAGES.syntax);
      this.code = code;
    }
  }
  const fail = (code) => new CalcError(code);

  /* ───────────── вспомогательное ───────────── */

  const isBig = (v) => typeof v === 'bigint';
  const absB = (b) => (b < 0n ? -b : b);
  const bitLen = (b) => absB(b).toString(2).length;
  const num = (v) => (isBig(v) ? Number(v) : v);

  // натуральный логарифм положительного BigInt (работает и за пределами double)
  function bigLog(b) {
    const s = b.toString();
    const head = Math.min(s.length, 15);
    return Math.log(Number(s.slice(0, head))) + (s.length - head) * Math.LN10;
  }

  function checkNum(x) {
    if (Number.isNaN(x)) throw fail('syntax');
    if (!Number.isFinite(x)) throw fail('overflow');
    return x === 0 ? 0 : x; // убираем -0
  }

  /* ───────────── арифметика ───────────── */

  function add(a, b) {
    if (isBig(a) && isBig(b)) {
      const r = a + b;
      if (bitLen(r) <= MAX_BITS) return r;
    }
    return checkNum(num(a) + num(b));
  }

  function sub(a, b) {
    if (isBig(a) && isBig(b)) {
      const r = a - b;
      if (bitLen(r) <= MAX_BITS) return r;
    }
    return checkNum(num(a) - num(b));
  }

  function mul(a, b) {
    if (isBig(a) && isBig(b)) {
      const r = a * b;
      if (bitLen(r) <= MAX_BITS) return r;
    }
    return checkNum(num(a) * num(b));
  }

  function div(a, b) {
    if (isBig(b) ? b === 0n : b === 0) throw fail('div0');
    if (isBig(a) && isBig(b)) {
      if (a % b === 0n) return a / b;
      const x = Number(a);
      const y = Number(b);
      if (Number.isFinite(x) && Number.isFinite(y)) return checkNum(x / y);
      const sign = (a < 0n) !== (b < 0n) ? -1 : 1;
      return checkNum(sign * Math.exp(bigLog(absB(a)) - bigLog(absB(b))));
    }
    return checkNum(num(a) / num(b));
  }

  function pow(a, b) {
    // точный путь: целое в неотрицательной целой степени
    if (isBig(a) && isBig(b) && b >= 0n) {
      if (a === 0n && b === 0n) throw fail('zero0');
      if (a === 0n || a === 1n) return a;
      if (a === -1n) return b % 2n === 0n ? 1n : -1n;
      const estBits = Number(b) * Math.log2(Number(absB(a)));
      if (estBits <= MAX_BITS) return a ** b;
    }

    const x = num(a);
    const y = num(b);
    const hugeBase = isBig(a) && !Number.isFinite(x);

    if (!hugeBase) {
      if (x === 0 && y === 0) throw fail('zero0');
      if (x === 0 && y < 0) throw fail('div0');
    }
    if (x < 0 && !Number.isInteger(y)) throw fail('noreal');

    let r;
    if (hugeBase) {
      const oddNeg = x < 0 && Math.abs(y) % 2 === 1;
      r = Math.exp(y * bigLog(absB(a))) * (oddNeg ? -1 : 1);
    } else {
      r = Math.pow(x, y);
    }
    if (Number.isNaN(r)) throw fail('syntax');
    if (!Number.isFinite(r)) throw fail('overflow');
    if (r === 0 && x !== 0) throw fail('underflow');
    return r === 0 ? 0 : r;
  }

  // floor(x^(1/n)) для x ≥ 0, n ≥ 1 (BigInt)
  function iroot(x, n) {
    if (x < 2n || n === 1n) return x;
    let lo = 0n;
    let hi = 1n << BigInt(Math.floor(bitLen(x) / Number(n)) + 1);
    while (lo < hi) {
      const mid = (lo + hi + 1n) >> 1n;
      if (mid ** n <= x) lo = mid;
      else hi = mid - 1n;
    }
    return lo;
  }

  // корень степени n из x
  function root(n, x) {
    const nn = num(n);
    if (nn === 0) throw fail('badroot');

    // точный путь: полный квадрат, куб и т.д.
    if (isBig(n) && isBig(x) && n > 0n && n <= 4096n) {
      const negative = x < 0n;
      if (negative && n % 2n === 0n) throw fail('noreal');
      const ax = negative ? -x : x;
      const r = iroot(ax, n);
      if (r ** n === ax) return negative ? -r : r;
    }

    const xNeg = isBig(x) ? x < 0n : x < 0;
    const oddInt = Number.isInteger(nn) && Math.abs(nn) % 2 === 1;
    if (xNeg && !oddInt) throw fail('noreal');

    const a = isBig(x) ? absB(x) : Math.abs(x);
    if (a === 0 || a === 0n) {
      if (nn < 0) throw fail('div0');
      return 0;
    }
    const k = Math.abs(nn);
    const an = num(a);
    let r;
    if (Number.isFinite(an)) {
      r = k === 2 ? Math.sqrt(an) : k === 3 ? Math.cbrt(an) : Math.pow(an, 1 / k);
    } else {
      r = Math.exp(bigLog(a) / k);
    }
    if (nn < 0) r = 1 / r;
    if (xNeg) r = -r;
    return checkNum(r);
  }

  /* ───────────── токенайзер ───────────── */

  const NUM_RE = /(?:\d+\.?\d*|\.\d+)(?:E[+-]?\d+)?/y;
  const OP_MAP = { '+': '+', '−': '−', '-': '−', '–': '−', '×': '×', '*': '×', '÷': '÷', '/': '÷' };
  const SYMBOLS = '^()%√';

  function tokenize(src) {
    const out = [];
    let i = 0;
    while (i < src.length) {
      const c = src[i];
      if (c === ' ' || c === NNBSP || c === '\u00a0') { i++; continue; }
      NUM_RE.lastIndex = i;
      const m = NUM_RE.exec(src);
      if (m) { out.push({ k: 'num', v: m[0] }); i += m[0].length; continue; }
      if (Object.prototype.hasOwnProperty.call(OP_MAP, c)) { out.push({ k: 'op', v: OP_MAP[c] }); i++; continue; }
      if (SYMBOLS.includes(c)) { out.push({ k: 'sym', v: c }); i++; continue; }
      throw fail('syntax');
    }
    return out;
  }

  function literal(text) {
    if (/^\d+$/.test(text) && text.length <= MAX_LITERAL_DIGITS) return BigInt(text);
    const v = parseFloat(text);
    if (!Number.isFinite(v)) throw fail('overflow');
    return v;
  }

  /* ───────────── парсер (рекурсивный спуск) ─────────────
   *
   * expr    := term (('+' | '−') term)*
   * term    := unary (('×' | '÷') unary)*        + неявное умножение перед скобкой: 2(3+4)
   * unary   := ('−' | '+') unary | power
   * power   := postfix ('^' signedPower)?         правоассоциативно: 2^3^2 = 2^9
   * postfix := primary '%'*
   * primary := atom ('√' rootOperand)*            n√x — корень степени n
   * atom    := число | '(' expr ')' | '√' rootOperand   √x — квадратный корень
   */
  function parse(tokens) {
    let p = 0;
    const isSym = (v) => tokens[p] && tokens[p].k === 'sym' && tokens[p].v === v;
    const isOp = (...vs) => tokens[p] && tokens[p].k === 'op' && vs.includes(tokens[p].v);

    function expr() {
      let l = term();
      while (isOp('+', '−')) {
        const op = tokens[p++].v;
        l = { t: 'bin', op, l, r: term() };
      }
      return l;
    }

    function term() {
      let l = unary();
      for (;;) {
        if (isOp('×', '÷')) {
          const op = tokens[p++].v;
          l = { t: 'bin', op, l, r: unary() };
        } else if (isSym('(')) {
          l = { t: 'bin', op: '×', l, r: unary() };
        } else {
          return l;
        }
      }
    }

    function unary() {
      if (isOp('−')) { p++; return { t: 'neg', x: unary() }; }
      if (isOp('+')) { p++; return unary(); }
      return power();
    }

    function power() {
      const b = postfix();
      if (isSym('^')) { p++; return { t: 'pow', b, e: signedPower() }; }
      return b;
    }

    function signedPower() {
      if (isOp('−')) { p++; return { t: 'neg', x: signedPower() }; }
      if (isOp('+')) { p++; return signedPower(); }
      return power();
    }

    function postfix() {
      let x = primary();
      while (isSym('%')) { p++; x = { t: 'pct', x }; }
      return x;
    }

    function primary() {
      let node = atom();
      while (isSym('√')) { p++; node = { t: 'root', n: node, x: rootOperand() }; }
      return node;
    }

    function rootOperand() {
      if (isOp('−')) { p++; return { t: 'neg', x: rootOperand() }; }
      if (isOp('+')) { p++; return rootOperand(); }
      return atom();
    }

    function atom() {
      const t = tokens[p];
      if (!t) throw fail('syntax');
      if (t.k === 'num') { p++; return { t: 'num', v: literal(t.v) }; }
      if (isSym('(')) {
        p++;
        const x = expr();
        if (!isSym(')')) throw fail('syntax');
        p++;
        return x;
      }
      if (isSym('√')) { p++; return { t: 'root', n: null, x: rootOperand() }; }
      throw fail('syntax');
    }

    const ast = expr();
    if (p !== tokens.length) throw fail('syntax');
    return ast;
  }

  /* ───────────── вычисление ───────────── */

  function evalNode(n) {
    switch (n.t) {
      case 'num': return n.v;
      case 'neg': return -evalNode(n.x);
      case 'pct': return div(evalNode(n.x), 100n);
      case 'pow': return pow(evalNode(n.b), evalNode(n.e));
      case 'root': return root(n.n === null ? 2n : evalNode(n.n), evalNode(n.x));
      case 'bin': {
        const l = evalNode(n.l);
        // «100 + 10%» = 110: процент считается от левого операнда
        if ((n.op === '+' || n.op === '−') && n.r.t === 'pct') {
          const amount = div(mul(l, evalNode(n.r.x)), 100n);
          return n.op === '+' ? add(l, amount) : sub(l, amount);
        }
        const r = evalNode(n.r);
        switch (n.op) {
          case '+': return add(l, r);
          case '−': return sub(l, r);
          case '×': return mul(l, r);
          default: return div(l, r);
        }
      }
      default: throw fail('syntax');
    }
  }

  function evaluate(src) {
    const tokens = tokenize(src);
    if (!tokens.length) throw fail('syntax');
    const v = evalNode(parse(tokens));
    return typeof v === 'number' ? checkNum(v) : v;
  }

  // убирает «висящие» операторы в конце и закрывает незакрытые скобки
  function prepare(src) {
    let s = src.replace(/[+−×÷^√(\-*/]+$/, '');
    let open = 0;
    for (const c of s) {
      if (c === '(') open++;
      else if (c === ')') open--;
    }
    if (open > 0) s += ')'.repeat(open);
    return s;
  }

  const isPlainNumber = (s) => /^[−-]?(?:\d+\.?\d*|\.\d+)(?:E[+-]?\d+)?$/.test(s);

  /* ───────────── отображение ───────────── */

  const group = (intStr) => intStr.replace(/\B(?=(\d{3})+(?!\d))/g, NNBSP);

  function sciParts(sign, digits, exp) {
    const rest = digits.slice(1).replace(/0+$/, '');
    const mant = digits[0] + (rest ? ',' + rest : '');
    const e = exp < 0 ? '−' + -exp : String(exp);
    return { html: `${sign}${mant}×10<sup>${e}</sup>`, text: `${sign}${mant}×10^${e}`, exact: null };
  }

  // → { html, text, exact }; exact — все цифры длинного целого (или null)
  function format(v) {
    if (isBig(v)) {
      const sign = v < 0n ? '−' : '';
      const s = absB(v).toString();
      if (s.length <= 15) {
        const t = sign + group(s);
        return { html: t, text: t, exact: null };
      }
      const head = BigInt(s.slice(0, 10));
      let digits = (s.charCodeAt(10) >= 53 ? head + 1n : head).toString();
      let exp = s.length - 1;
      if (digits.length > 10) { digits = digits.slice(0, 10); exp += 1; }
      const r = sciParts(sign, digits, exp);
      r.exact = sign + group(s);
      return r;
    }

    const x = v === 0 ? 0 : v;
    if (x === 0) return { html: '0', text: '0', exact: null };
    const r = Number.isInteger(x) ? x : parseFloat(x.toPrecision(12));
    const ar = Math.abs(r);
    const sign = x < 0 ? '−' : '';

    if (ar >= 1e15 || ar < 1e-6) {
      const m = /^-?(\d)(?:\.(\d+))?e([+-]\d+)$/.exec(x.toExponential(9));
      return sciParts(sign, m[1] + (m[2] || ''), parseInt(m[3], 10));
    }
    const [ip, fp] = ar.toString().split('.');
    const t = sign + group(ip) + (fp ? ',' + fp : '');
    return { html: t, text: t, exact: null };
  }

  // строка, которую можно снова подставить в выражение
  function serialize(v) {
    if (isBig(v)) return v.toString();
    if (v === 0) return '0';
    const p = parseFloat(v.toPrecision(15));
    const a = Math.abs(p);
    if (a >= 1e21 || a < 1e-6) return p.toExponential().toUpperCase();
    return String(p);
  }

  return { evaluate, prepare, format, serialize, isPlainNumber, group, CalcError, MESSAGES };
});
